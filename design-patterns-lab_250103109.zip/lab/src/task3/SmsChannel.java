package task3;

public class SmsChannel implements MessageChannel {
    @Override
    public void transmit(String recipient, String message) {
        String condensed = message.replace("\n", " -- ");
        System.out.println("[SMS PROTOCOL -> " + recipient + "] " + condensed);
    }
}
