package task5;

public class AudioAsset extends DigitalAsset {
    public AudioAsset(StorageDriver driver, String assetPath) {
        super(driver, assetPath);
    }

    @Override
    public void render() {
        System.out.println("Initializing Audio Stream for: " + assetPath);
        byte[] payload = driver.loadRawBlob(assetPath);
        if (payload.length > 0) {
            System.out.println("SUCCESS: Audio bitstream synchronized " + payload.length + " bytes via " + driver.getStorageType());
        } else {
            System.out.println("FAILURE: Audio stream inaccessible.");
        }
    }
}
