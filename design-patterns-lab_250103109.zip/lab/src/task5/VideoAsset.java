package task5;

public class VideoAsset extends DigitalAsset {
    public VideoAsset(StorageDriver driver, String assetPath) {
        super(driver, assetPath);
    }

    @Override
    public void render() {
        System.out.println("Initializing Video Player for: " + assetPath);
        byte[] payload = driver.loadRawBlob(assetPath);
        if (payload.length > 0) {
            System.out.println("SUCCESS: Video playback buffered " + payload.length + " bytes via " + driver.getStorageType());
        } else {
            System.out.println("FAILURE: Video buffer empty. Playback aborted.");
        }
    }
}
