package task5;

public class StorageDriverProxy implements StorageDriver {
    private final StorageDriver realDriver;
    private final UserSession session;

    public StorageDriverProxy(StorageDriver realDriver, UserSession session) {
        if (realDriver == null || session == null) {
            throw new IllegalArgumentException("Dependencies cannot be null");
        }
        this.realDriver = realDriver;
        this.session = session;
    }

    @Override
    public byte[] loadRawBlob(String resourceUri) {
        if ("GUEST".equalsIgnoreCase(session.getRole())) {
            System.out.println("[PROXY BLOCKED] Access Denied for User '" + session.getUsername()
                    + "' [Role: " + session.getRole() + "] on resource: " + resourceUri);
            return new byte[0];
        }
        System.out.println("[PROXY AUDIT] Authorized user '" + session.getUsername()
                + "' [Role: " + session.getRole() + "] accessing backend: " + realDriver.getStorageType());
        return realDriver.loadRawBlob(resourceUri);
    }

    @Override
    public String getStorageType() {
        return "PROXY_GUARDED(" + realDriver.getStorageType() + ")";
    }
}
